package com.example.javaspringbootwelcomepack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringBootWelcomePackApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringBootWelcomePackApplication.class, args);
	}

}
