package com.example.javaspringbootwelcomepack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringBootWelcomePackApplicationTests {

	@Test
	void contextLoads() {
	}

}
